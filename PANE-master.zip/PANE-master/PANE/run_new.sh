make
make sock
#gnome-terminal -x sh -c "(sleep 1; cd ../booksim2-master/src/;   ./run.sh >dump ; )"
./PANE -u Cmdenv -f omnetpp.ini
#./PANE
