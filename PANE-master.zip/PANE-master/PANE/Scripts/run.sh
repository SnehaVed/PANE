make
make sock
./PANE -u Cmdenv -f omnetpp.ini

