make -j4
./booksim ./examples/bitrev
