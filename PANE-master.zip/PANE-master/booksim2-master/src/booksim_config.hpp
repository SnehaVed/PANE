// $Id$


#ifndef _BOOKSIM_CONFIG_HPP_
#define _BOOKSIM_CONFIG_HPP_

#include "config_utils.hpp"

class BookSimConfig : public Configuration {
protected:

public:
  BookSimConfig( );
};

#endif

#ifndef _POWER_CONFIG_HPP_
#define _POWER_CONFIG_HPP_

#include "config_utils.hpp"

class PowerConfig : public Configuration {
public:
  PowerConfig( );

};

#endif
