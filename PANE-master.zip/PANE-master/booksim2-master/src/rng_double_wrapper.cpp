// $Id$


#define main rng_double_main
#include "rng-double.c"

double ranf_next( )
{
  return ranf_arr_next( );
}
